<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['module_config'] = array(
	'menus'	=> array(
		'developer'	=> 'database/developer/menu'
	),
	'author'		=> 'Bonfire Team',
	'description'	=> 'Provides tools for working with your database(s).',
	'menu_topic'	=> array(
		'developer'		=>'Database Tools'
	)
);