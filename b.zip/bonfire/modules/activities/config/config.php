<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['module_config'] = array(
	'description'	=> 'Allows other modules to store user activity information.',
	'author'		=> 'Bonfire Team',
	'name'			=> 'Activities'
);