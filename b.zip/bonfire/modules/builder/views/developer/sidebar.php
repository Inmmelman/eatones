<div class="well" style="padding: 8px 0">
	
	<ul class="nav nav-list">
		<li class="nav-header"><?php echo lang('mb_tools'); ?></li>
		<li><a href="<?php echo site_url(SITE_AREA .'/developer/builder/create_module') ?>"><?php echo lang('mb_mod_builder') ?></a></li>
		<li><a href="<?php echo site_url(SITE_AREA .'/developer/builder/create_context') ?>"><?php echo lang('mb_new_context') ?></a></li>
	</ul>
	
</div>