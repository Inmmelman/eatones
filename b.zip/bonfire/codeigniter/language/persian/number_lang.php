<?php

$lang['terabyte_abbr'] = 'ترابایت';
$lang['gigabyte_abbr'] = 'گیگابایت';
$lang['megabyte_abbr'] = 'مگابایت';
$lang['kilobyte_abbr'] = 'كیلوبایت';
$lang['bytes'] = 'بایت';
?>