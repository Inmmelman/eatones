<?php

$lang['ut_test_name'] = 'Nombre del test';
$lang['ut_test_datatype'] = 'Tipo de datos del test';
$lang['ut_res_datatype'] = 'Tipo de datos esperados';
$lang['ut_result'] = 'Resultado';
$lang['ut_undefined'] = 'Nombre de test no definido';
$lang['ut_file'] = 'Nombre fichero';
$lang['ut_line'] = 'Número de línea';
$lang['ut_passed'] = 'Pasado';
$lang['ut_failed'] = 'Fallido';
$lang['ut_boolean'] = 'Booleano';
$lang['ut_integer'] = 'Entero';
$lang['ut_float'] = 'Flotante';
$lang['ut_double'] = 'Flotante';
$lang['ut_string'] = 'Cadena';
$lang['ut_array'] = 'Matriz';
$lang['ut_object'] = 'Objeto';
$lang['ut_resource'] = 'Recurso';
$lang['ut_null'] = 'Null';
$lang['ut_notes'] = 'Notas';
?>