<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['mainpageconstructor_manage']			= 'Manage MainPageConstructor';
$lang['mainpageconstructor_edit']				= 'Edit';
$lang['mainpageconstructor_true']				= 'True';
$lang['mainpageconstructor_false']				= 'False';
$lang['mainpageconstructor_create']			= 'Create';
$lang['mainpageconstructor_list']				= 'List';
$lang['mainpageconstructor_new']				= 'New';
$lang['mainpageconstructor_edit_text']			= 'Edit this to suit your needs';
$lang['mainpageconstructor_no_records']		= 'There aren\'t any mainpageconstructor in the system.';
$lang['mainpageconstructor_create_new']		= 'Create a new MainPageConstructor.';
$lang['mainpageconstructor_create_success']	= 'MainPageConstructor successfully created.';
$lang['mainpageconstructor_create_failure']	= 'There was a problem creating the mainpageconstructor: ';
$lang['mainpageconstructor_create_new_button']	= 'Create New MainPageConstructor';
$lang['mainpageconstructor_invalid_id']		= 'Invalid MainPageConstructor ID.';
$lang['mainpageconstructor_edit_success']		= 'MainPageConstructor successfully saved.';
$lang['mainpageconstructor_edit_failure']		= 'There was a problem saving the mainpageconstructor: ';
$lang['mainpageconstructor_delete_success']	= 'record(s) successfully deleted.';
$lang['mainpageconstructor_delete_failure']	= 'We could not delete the record: ';
$lang['mainpageconstructor_delete_error']		= 'You have not selected any records to delete.';
$lang['mainpageconstructor_actions']			= 'Actions';
$lang['mainpageconstructor_cancel']			= 'Cancel';
$lang['mainpageconstructor_delete_record']		= 'Delete this MainPageConstructor';
$lang['mainpageconstructor_delete_confirm']	= 'Are you sure you want to delete this mainpageconstructor?';
$lang['mainpageconstructor_edit_heading']		= 'Edit MainPageConstructor';

// Create/Edit Buttons
$lang['mainpageconstructor_action_edit']		= 'Save MainPageConstructor';
$lang['mainpageconstructor_action_create']		= 'Create MainPageConstructor';

// Activities
$lang['mainpageconstructor_act_create_record']	= 'Created record with ID';
$lang['mainpageconstructor_act_edit_record']	= 'Updated record with ID';
$lang['mainpageconstructor_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['mainpageconstructor_column_created']	= 'Created';
$lang['mainpageconstructor_column_deleted']	= 'Deleted';
$lang['mainpageconstructor_column_modified']	= 'Modified';
