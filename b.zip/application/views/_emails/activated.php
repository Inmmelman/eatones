<p>Congratulations. Your account on the <?php e($title); ?> site is now registered and active!</p>

<p><a href="<?php echo $link ?>"><?php echo $link ?></a></p>