<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    $config['social.vk'] = array(
                'client_id'=>4126470,
                'client_secret'=> 'zSSQU023Hincg4ESL4Z8',
                'redirect_uri' => 'http://www.buhaem/public/index.php/users/socialauth/auth/?provider=vk'
    );

    $config['social.facebook'] = array(
                'client_id'=> '257997651030821',
                'client_secret'=> '78b715c3a5cc121bceef9f926b2ea7de',
                'redirect_uri' => 'http://www.buhaem/public/index.php/users/socialauth/auth/?provider=facebook'
    );
